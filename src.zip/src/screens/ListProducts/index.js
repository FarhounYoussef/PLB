/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
  Text,
  AppState,
} from 'react-native';
import ProductLits from './ProductList';

const DATA = [
  {
    id: 1,
    product: 'Product 1',
    description: 'Desc Product 1',
    prix: 100,
    stock: 2,
    image:
      'https://cdn.futura-sciences.com/buildsv6/images/mediumoriginal/e/a/a/eaa5f0bd77_50166388_chat-gris.jpg',
  },
  {
    id: 2,
    product: 'Product 2',
    description:
      'Desc Product 2 jhvkjdshvkjsbvkbsdkvbskb kadbvhsdvbc kbahcdacv  hahcvjhadcv hgahcvuhadc hgaicaduv gaisgcuyadc  yacsuvadc iugibihb ciaciadvc aicbavdc kjbicbia',
    prix: 100,
    stock: 2,
    image:
      'https://cdn.futura-sciences.com/buildsv6/images/mediumoriginal/e/a/a/eaa5f0bd77_50166388_chat-gris.jpg',
  },
  {
    id: 3,
    product: 'Product 3',
    description: 'Desc Product 3',
    prix: 100,
    stock: 2,
    image:
      'https://cdn.futura-sciences.com/buildsv6/images/mediumoriginal/e/a/a/eaa5f0bd77_50166388_chat-gris.jpg',
  },
  {
    id: 4,
    product: 'Product 4',
    description: 'Desc Product 4',
    prix: 100,
    stock: 2,
    image:
      'https://cdn.futura-sciences.com/buildsv6/images/mediumoriginal/e/a/a/eaa5f0bd77_50166388_chat-gris.jpg',
  },
];

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      search: 'test',
      filtedData: DATA,
    };
  }

  filterProducts = () => {
    const newData = DATA.filter(produit =>
      produit.product.includes(this.state.search),
    );
    this.setState({filtedData: newData});
  };

  render() {
    return (
      <SafeAreaView style={styles.wrapper}>
        <View style={styles.searchContainer}>
          <TextInput
            ref={ref => (this.ref = ref)}
            style={styles.input}
            value={this.state.search}
            onChangeText={_value => {
              this.setState({search: _value});
            }}
          />
          <TouchableOpacity
            style={styles.button}
            onPress={() => {
              this.ref.focus();
            }}>
            <Text style={styles.searchTitle}>Search</Text>
          </TouchableOpacity>
        </View>
        <ProductLits data={this.state.filtedData} />
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    margin: 5,
  },
  input: {
    flex: 1,
  },
  button: {
    padding: 10,
    backgroundColor: 'red',
    borderRadius: 15,
  },
  searchTitle: {
    color: 'white',
    fontWeight: '700',
  },
});

export default App;
